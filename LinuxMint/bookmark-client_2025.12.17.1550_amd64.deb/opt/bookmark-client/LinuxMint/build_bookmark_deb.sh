#!/usr/bin/env bash
set -euo pipefail

# Build a .deb for Linux Mint / Ubuntu using fpm (dir -> deb).
# It installs the app into /opt/bookmark-client and provides:
#   - /usr/local/bin/bookmark-client  (CLI launcher)
#   - desktop entry (menu)
#
# Dependencies are declared in the .deb:
#   - python3
#   - python3-tk   (tkinter for system Python)
#   - xdg-utils    (xdg-open for opening URLs/files)
#
# Usage:
#   chmod +x build_bookmark_deb.sh
#   ./build_bookmark_deb.sh
#
# Install the built package (recommended so deps are pulled in):
#   sudo apt install ./bookmark-client_<version>_<arch>.deb

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

PKG_NAME="${PKG_NAME:-bookmark-client}"
APP_DIR="/opt/${PKG_NAME}"
BIN_NAME="${BIN_NAME:-bookmark-client}"

# Choose entrypoint automatically (override via ENTRYPOINT=...)
ENTRYPOINT="${ENTRYPOINT:-}"
if [[ -z "$ENTRYPOINT" ]]; then
  if [[ -f "bookmark_improved.py" ]]; then
    ENTRYPOINT="bookmark_improved.py"
  elif [[ -f "bookmark.py" ]]; then
    ENTRYPOINT="bookmark.py"
  else
    echo "ERROR: Could not find bookmark_improved.py or bookmark.py in: $PROJECT_DIR"
    echo "Set ENTRYPOINT to your main python file, e.g.:"
    echo "  ENTRYPOINT=main.py ./build_bookmark_deb.sh"
    exit 2
  fi
fi

ARCH="$(dpkg --print-architecture)"
VERSION="${VERSION:-$(date +%Y.%m.%d.%H%M)}"
BUILD_DIR="${BUILD_DIR:-$PROJECT_DIR/build}"
STAGE="${BUILD_DIR}/pkgroot"

DESC="${DESC:-Simple Tkinter bookmark client}"
MAINT="${MAINT:-Knud}"
URL="${URL:-https://it3home.dk}"

need_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "ERROR: Missing command: $1"
    exit 3
  fi
}

need_cmd fpm
need_cmd python3

# If requirements.txt exists, we will vendor dependencies into the package dir.
if [[ -f "requirements.txt" ]]; then
  # pip is commonly available as python3 -m pip, but not always installed.
  if ! python3 -m pip --version >/dev/null 2>&1; then
    echo "ERROR: requirements.txt exists but pip is not available."
    echo "Install build prereqs and retry:"
    echo "  sudo apt update && sudo apt install -y python3-pip"
    exit 4
  fi
fi

echo "Project    : $PROJECT_DIR"
echo "Package    : $PKG_NAME"
echo "Version    : $VERSION"
echo "Arch       : $ARCH"
echo "Entrypoint : $ENTRYPOINT"
echo

echo "[1/6] Cleaning build dir..."
rm -rf "$STAGE"
mkdir -p "$STAGE"

echo "[2/6] Staging application files..."
mkdir -p "$STAGE${APP_DIR}"

# Copy project files while excluding common junk
if command -v rsync >/dev/null 2>&1; then
  rsync -a     --exclude '.venv'     --exclude 'build'     --exclude '__pycache__'     --exclude '*.pyc'     --exclude '.git'     --exclude '.mypy_cache'     --exclude '.pytest_cache'     ./ "$STAGE${APP_DIR}/"
else
  # Fallback if rsync is missing
  tar --exclude='./.venv'       --exclude='./build'       --exclude='./__pycache__'       --exclude='./.git'       -cf - . | tar -xf - -C "$STAGE${APP_DIR}"
fi

# Make sure entrypoint exists inside staged dir
if [[ ! -f "$STAGE${APP_DIR}/${ENTRYPOINT}" ]]; then
  echo "ERROR: Entrypoint not found in staged dir: $STAGE${APP_DIR}/${ENTRYPOINT}"
  exit 5
fi

echo "[3/6] Vendoring Python deps (optional)..."
VENDOR_DIR="$STAGE${APP_DIR}/vendor"
if [[ -f "requirements.txt" ]]; then
  mkdir -p "$VENDOR_DIR"
  python3 -m pip install --upgrade pip >/dev/null
  python3 -m pip install --no-compile --no-cache-dir --target "$VENDOR_DIR" -r "requirements.txt"
else
  echo "No requirements.txt found, skipping vendoring."
fi

echo "[4/6] Creating launcher script..."
mkdir -p "$STAGE/usr/local/bin"
cat > "$STAGE/usr/local/bin/${BIN_NAME}" <<'SH'
#!/usr/bin/env bash
set -euo pipefail

APP_DIR="__APP_DIR__"
ENTRYPOINT="__ENTRYPOINT__"

# Add vendored deps if present
if [[ -d "${APP_DIR}/vendor" ]]; then
  export PYTHONPATH="${APP_DIR}/vendor:${PYTHONPATH:-}"
fi

exec /usr/bin/python3 "${APP_DIR}/${ENTRYPOINT}" "$@"
SH

# Patch placeholders safely
sed -i "s#__APP_DIR__#${APP_DIR}#g" "$STAGE/usr/local/bin/${BIN_NAME}"
sed -i "s#__ENTRYPOINT__#${ENTRYPOINT}#g" "$STAGE/usr/local/bin/${BIN_NAME}"
chmod 0755 "$STAGE/usr/local/bin/${BIN_NAME}"

echo "[5/6] Creating desktop entry (optional)..."
mkdir -p "$STAGE/usr/share/applications"
cat > "$STAGE/usr/share/applications/${PKG_NAME}.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Bookmark Client
Comment=${DESC}
Exec=${BIN_NAME}
Terminal=false
Categories=Utility;
EOF

# Optional icon support: if you have icon.png in the project root, it will be installed.
if [[ -f "icon.png" ]]; then
  mkdir -p "$STAGE/usr/share/icons/hicolor/256x256/apps"
  cp -f "icon.png" "$STAGE/usr/share/icons/hicolor/256x256/apps/${PKG_NAME}.png"
  # Update desktop entry to point to the icon
  echo "Icon=${PKG_NAME}" >> "$STAGE/usr/share/applications/${PKG_NAME}.desktop"
fi

echo "[6/6] Building .deb with fpm..."
OUT_DEB="${PKG_NAME}_${VERSION}_${ARCH}.deb"

fpm -s dir -t deb   -n "${PKG_NAME}"   -v "${VERSION}"   -a "${ARCH}"   --description "${DESC}"   --url "${URL}"   --maintainer "${MAINT}"   -d "python3"   -d "python3-tk"   -d "xdg-utils"   -C "$STAGE"   -p "$OUT_DEB"   .

echo
echo "Built: ${PROJECT_DIR}/${OUT_DEB}"
